from __future__ import absolute_import, division, print_function

import warnings

from builtins import *  # @UnusedWildImport
import pytest

from mcculw import ul
from mcculw.enums import ErrorCode, DigitalIODirection
from examples.props.digital import DigitalProps
from mcculw.ul import ULError


class TestDIn(object):
    def test_d_in(self):
        board_num = 0
        digital_props = DigitalProps(board_num)

        # Find the first port that supports input, defaulting to None
        # if one is not found.
        port = next((port for port in digital_props.port_info
                     if port.supports_input), None)

        if port == None:
            warnings.warn(
                "No digital input ports found on board " + str(board_num))
            return

        if port.is_port_configurable:
            ul.d_config_port(board_num, port.type, DigitalIODirection.IN)

        try:
            ul.d_in(board_num, port.type)
        except ULError as e:
            if e.errorcode == ErrorCode.BADBOARDTYPE:
                warnings.warn(
                    "d_in is not supported by board "
                    + str(board_num))
            else:
                raise

    def test_d_bit_in(self):
        board_num = 0
        digital_props = DigitalProps(board_num)

        # Find the first port that supports input, defaulting to None
        # if one is not found.
        port = next((port for port in digital_props.port_info
                     if port.supports_input), None)

        if port == None:
            warnings.warn(
                "No digital input ports found on board " + str(board_num))
            return

        if port.is_port_configurable:
            ul.d_config_port(board_num, port.type, DigitalIODirection.IN)

        try:
            ul.d_bit_in(board_num, port.type, port.first_bit)
        except ULError as e:
            if e.errorcode == ErrorCode.BADBOARDTYPE:
                warnings.warn(
                    "d_bit_in is not supported by board "
                    + str(board_num))
            else:
                raise


# If this module is run directly, start pytest (allows for easy debugging).
if __name__ == "__main__":
    pytest.main(['-rw'])
