from __future__ import absolute_import, division, print_function

import warnings

from builtins import *  # @UnusedWildImport
import pytest

from mcculw import ul
from mcculw.enums import ULRange, ErrorCode
from mcculw.ul import ULError


class TestAOut(object):
    def test_a_out(self):
        board_num = 0
        channel = 0
        ul_range = ULRange.BIP10VOLTS

        try:
            ul.a_out(board_num, channel, ul_range, 0)
        except ULError as e:
            if e.errorcode == ErrorCode.BADBOARDTYPE:
                warnings.warn(
                    "a_out is not supported by board "
                    + str(board_num))
            else:
                raise


# If this module is run directly, start pytest (allows for easy debugging).
if __name__ == "__main__":
    pytest.main(['-rw'])
