from __future__ import absolute_import, division, print_function

import warnings

from builtins import *  # @UnusedWildImport
import pytest

from mcculw import ul
from mcculw.enums import ULRange, ErrorCode
from mcculw.ul import ULError


class TestAIn(object):
    def test_a_in(self):
        board_num = 0
        channel = 0
        ul_range = ULRange.BIP10VOLTS
        try:
            ul.a_in(board_num, channel, ul_range)
        except ULError as e:
            if e.errorcode == ErrorCode.BADBOARDTYPE:
                warnings.warn(
                    "a_in is not supported by board "
                    + str(board_num))
            else:
                raise

    def test_a_in_32(self):
        board_num = 0
        channel = 0
        ul_range = ULRange.BIP10VOLTS

        try:
            ul.a_in_32(board_num, channel, ul_range)
        except ULError as e:
            if e.errorcode == ErrorCode.BADBOARDTYPE:
                warnings.warn(
                    "a_in_32 is not supported by board "
                    + str(board_num))
            else:
                raise

    def test_a_in_scan(self):
        board_num = 0
        low_chan = 0
        high_chan = 0
        rate = 100
        num_points = 10
        ul_range = ULRange.BIP10VOLTS

        memhandle = ul.win_buf_alloc_32(num_points)
        assert memhandle != 0

        try:
            ul.a_in_scan(board_num, low_chan, high_chan, num_points,
                         rate, ul_range, memhandle, 0)
        except ULError as e:
            if e.errorcode == ErrorCode.BADBOARDTYPE:
                warnings.warn(
                    "a_in_scan is not supported by board "
                    + str(board_num))
            else:
                raise


# If this module is run directly, start pytest (allows for easy debugging).
if __name__ == "__main__":
    pytest.main(['-rw'])
