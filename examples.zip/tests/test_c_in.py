from __future__ import absolute_import, division, print_function

import warnings

from builtins import *  # @UnusedWildImport
import pytest

from mcculw import ul
from mcculw.enums import ErrorCode, CounterChannelType
from examples.props.counter import CounterProps
from mcculw.ul import ULError


class TestCIn(object):
    def test_c_in(self):
        board_num = 0
        ci_props = CounterProps(board_num)
        if len(ci_props.counter_info) > 0:
            channel = ci_props.counter_info[0].channel_num
        else:
            # If no counter channels exist, set the value to 0.  This way,
            # c_in will correctly check for the BADBOARDTYPE error or raise
            # a ULError indicating a board was not found.
            channel = 0

        try:
            ul.c_in(board_num, channel)
        except ULError as e:
            if e.errorcode == ErrorCode.BADBOARDTYPE:
                warnings.warn(
                    "c_in is not supported by board "
                    + str(board_num))
            else:
                raise

    def test_c_in_32(self):
        board_num = 0
        ci_props = CounterProps(board_num)
        if len(ci_props.counter_info) > 0:
            channel = ci_props.counter_info[0].channel_num
        else:
            # If no counter channels exist, set the value to 0.  This way,
            # c_in will correctly check for the BADBOARDTYPE error or raise
            # a ULError indicating a board was not found.
            channel = 0

        try:
            ul.c_in_32(board_num, channel)
        except ULError as e:
            if e.errorcode == ErrorCode.BADBOARDTYPE:
                warnings.warn(
                    "c_in_32 is not supported by board "
                    + str(board_num))
            else:
                raise

    def test_c_in_64(self):
        board_num = 0
        ci_props = CounterProps(board_num)
        if len(ci_props.counter_info) > 0:
            channel = ci_props.counter_info[0].channel_num
        else:
            # If no counter channels exist, set the value to 0.  This way,
            # c_in will correctly check for the BADBOARDTYPE error or raise
            # a ULError indicating a board was not found.
            channel = 0

        try:
            ul.c_in_64(board_num, channel)
        except ULError as e:
            if e.errorcode == ErrorCode.BADBOARDTYPE:
                warnings.warn(
                    "c_in_64 is not supported by board "
                    + str(board_num))
            else:
                raise

    def test_c_in_scan(self):
        board_num = 0
        ctr_props = CounterProps(board_num)

        if not ctr_props.supports_scan:
            warnings.warn(
                "c_in_scan is not supported by board " + str(board_num))
            return

        min_chan = next(
            (channel for channel in ctr_props.counter_info
             if channel.type == CounterChannelType.CTRSCAN
             or channel.type == CounterChannelType.CTRQUAD), None)
        max_chan = next(
            (channel for channel
             in reversed(ctr_props.counter_info)
             if channel.type == CounterChannelType.CTRSCAN
             or channel.type == CounterChannelType.CTRQUAD), None)

        if min_chan is None or max_chan is None:
            warnings.warn(
                "c_in_scan is supported, but no channels found on board "
                "number " + str(board_num))
            return

        low_chan = min_chan.channel_num
        high_chan = max_chan.channel_num
        rate = 1000
        points_per_channel = 10
        num_channels = high_chan - low_chan + 1
        total_count = points_per_channel * num_channels

        # Allocate a buffer for the scan
        memhandle = ul.win_buf_alloc_32(total_count)
        assert memhandle != 0

        # Run the scan
        ul.c_in_scan(
            board_num, low_chan, high_chan, total_count,
            rate, memhandle, 0)


# If this module is run directly, start pytest (allows for easy debugging).
if __name__ == "__main__":
    pytest.main(['-rw'])
