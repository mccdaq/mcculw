from __future__ import absolute_import, division, print_function

from builtins import *  # @UnusedWildImport
import pytest

from examples.console import a_in, v_in, a_out_scan, v_out,\
    a_in_scan_foreground
from examples.console import a_in_scan_background


class TestConsoleExamples(object):
    def test_console_examples(self):
        a_in_scan_foreground.run_example()
        a_in_scan_background.run_example()
        a_in.run_example()
        a_out_scan.run_example()
        v_in.run_example()
        v_out.run_example()


# If this module is run directly, start pytest (allows for easy debugging).
if __name__ == "__main__":
    pytest.main(['-rw'])
