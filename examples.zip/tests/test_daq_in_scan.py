from __future__ import absolute_import, division, print_function

import warnings

from builtins import *  # @UnusedWildImport
import pytest

from mcculw import ul
from mcculw.enums import DigitalPortType, ChannelType
from mcculw.enums import ULRange, ErrorCode
from mcculw.ul import ULError


class TestDaqInScan(object):
    def test_daq_in_scan(self):
        board_num = 0

        chan_list = [0, DigitalPortType.AUXPORT]
        chan_type_list = [ChannelType.ANALOG, ChannelType.DIGITAL]
        gain_list = [ULRange.BIP10VOLTS, ULRange.NOTUSED]

        chan_count = len(chan_list)
        rate = 100
        total_count = len(chan_list) * 10

        memhandle = ul.win_buf_alloc(total_count)
        assert memhandle != 0

        try:
            ul.daq_in_scan(
                board_num, chan_list, chan_type_list, gain_list, chan_count,
                rate, 0, total_count, memhandle, 0)
        except ULError as e:
            if e.errorcode == ErrorCode.BADBOARDTYPE:
                warnings.warn(
                    "daq_in_scan is not supported by board "
                    + str(board_num))
            else:
                raise
        finally:
            ul.win_buf_free(memhandle)


# If this module is run directly, start pytest (allows for easy debugging).
if __name__ == "__main__":
    pytest.main(['-rw'])
