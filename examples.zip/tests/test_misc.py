from __future__ import absolute_import, division, print_function

from builtins import *  # @UnusedWildImport
import pytest

from mcculw.enums import ScanOptions
from mcculw.enums import ULRange


class TestMisc(object):
    def test_scan_options(self):
        options_in = ScanOptions.BACKGROUND | ScanOptions.CONTINUOUS
        options_as_int = int(options_in)
        options_out = ScanOptions(options_as_int)

        assert options_in == options_out
        assert ScanOptions.BACKGROUND in options_out
        assert ScanOptions.CONTINUOUS in options_out

    def test_ul_range(self):
        range_in = ULRange.BIP10VOLTS
        range_as_int = int(range_in)
        range_out = ULRange(range_as_int)

        assert range_in == range_out
        assert range_in.range_min == -10
        assert range_in.range_max == 10


# If this module is run directly, start pytest (allows for easy debugging).
if __name__ == "__main__":
    pytest.main(['-rw'])
